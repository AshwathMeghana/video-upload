import { useRef, useState, useEffect } from "react";
import uploadicon from "./upload-icon.png";
import "./App.css";
import VideoProgressPopup from "./VideoProgressPopup";
import LoginPage from "./LoginPage";
import CircularProgress from "./CircularProgress";
import axios from "axios";
import socket from "./socket";  // 👈 import the singleton socket


function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [tabIndex, setTabIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef(null);
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [messages, setMessages] = useState([]);
  const [socketConnected, setSocketConnected] = useState(false); // ✅ use this stat
  // 🔹 Socket connection

  

  // useEffect(() => {
  //   const handleConnect = () => {
  //     console.log("Connected:", socket.id);
  //     setSocketConnected(true);

  //     socket.emit("username", "frontend");

  //     const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  //     if (currentUser) {
  //       socket.emit("reloadPage", "5");
  //     }
  //   };

  //   socket.on("connect", handleConnect);

  //   socket.on("disconnect", () => {
  //     console.log("Socket disconnected");
  //     setSocketConnected(false);
  //   });

  //   return () => {
  //     socket.off("connect", handleConnect);
  //   };
  // }, []);

  // 🔹 Runs once to simulate progress loading
  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((oldProgress) => {
        if (oldProgress >= 100) {
          clearInterval(timer);
          return 100;
        }
        return oldProgress + 1;
      });
    }, 100); // every 100ms

    return () => clearInterval(timer);
  }, []);

  const handleImageClick = () => {
    if (fileInputRef.current) fileInputRef.current.click();
  };

  const uploadVideo = async (file) => {
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await axios.post(
        "http://localhost:3000/api/uploads",
        formData
      );

      console.log("Upload success:", res.data);

      // Optionally notify backend via socket
      // socket.emit("videoUploaded", { fileName: file.name }); 
    } catch (error) {
      console.error("Upload failed:", error);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      uploadVideo(file);
    }
  };

  const handleLogout = () => setIsLoggedIn(false);

  if (!isLoggedIn) {
    return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  }

  const handleSelect = (index) => {
    if (selectedVideos.includes(index)) {
      setSelectedVideos(selectedVideos.filter((i) => i !== index));
    } else {
      setSelectedVideos([...selectedVideos, index]);
    }
  };

  return (
    <div className="App">
      <div className="AppHeader">
        <div className="left-section">
          <img
            src="/static/media/logo.39fbbbbe5208cdbdf802.png"
            className="App-logo"
            alt="logo"
          />
        </div>

        <div className="logout-btn" onClick={handleLogout}>
          Logout
        </div>
      </div>

      <div className="tab-container">
        <div className="tab-buttons">
          <button className={tabIndex === 0 ? "tabs selected-tab" : "tabs"} onClick={() => setTabIndex(0)}>Upload Videos</button>
          <hr />
          <button className={tabIndex === 1 ? "tabs selected-tab" : "tabs"} onClick={() => setTabIndex(1)}>Video Processing Details</button>
          <hr />
          <button className={tabIndex === 2 ? "tabs selected-tab" : "tabs"} onClick={() => setTabIndex(2)}>Video Processed Details</button>
        </div>
      </div>

      {tabIndex === 0 && (
        <div
          className="upload-outline"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <div className="upload-content">
            <img
              src={uploadicon}
              className="App-upload"
              alt="Upload Icon"
              onClick={handleImageClick}
              style={{ cursor: "pointer" }}
            />
            <input
              type="file"
              ref={fileInputRef}
              accept="video/*"
              onChange={(e) => uploadVideo(e.target.files[0])}
              style={{ display: "none" }}
            />
            <p className="text">Drag & Drop video here or click to upload</p>
          </div>
          <p>Socket connected: {socketConnected ? "✅" : "❌"}</p>
          <div>
            {messages.map((msg, i) => (
              <p key={i}>Backend: {JSON.stringify(msg)}</p>
            ))}
          </div>
        </div>
      )}

      {/* 🔹 Tab 2: Progress Bar */}

      {tabIndex === 1 && (
        <div className="page-container">
          <div className="split-screen">
            <div className="progress-container">
              <input
                type="text"
                placeholder="Search..."
                className="searchBar"
              />

              <div className="progress-bar">
                <div
                  className="progress-fill"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>

              <p className="progress-text">{progress.toFixed(1)}%</p>

              <div className="box-container">
                <div className="video-display">
                  {Array.from({ length: 100 }).map((_, i) => (
                    <div style={{ background: "white", padding: "10px", border: "black solid 2px", text: "black", borderRadius: '10px' }}>
                      <div>video name</div>
                      <div>Linear</div>
                      <CircularProgress value={86} />
                    </div>
                  ))}
                </div>
              </div>

              {selectedVideos.length > 0 && <button className="btn">STOP</button>}


            </div>
          </div>


          <div className="row">
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
            <div className="current-updates">
              <div className="value">15</div>
              <div>Unique videos</div>
            </div>
          </div>
        </div>

      )}
      {tabIndex === 2 && (
        <div className="split-screen">

        </div>
      )}

      {showPopup && <VideoProgressPopup onClose={() => setShowPopup(false)} />}
    </div>
  );
}

export default App;

